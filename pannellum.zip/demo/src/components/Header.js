import React from 'react';

export default () => {
  return (
    <header className="header">
      <div>
        <a 
          href="/"
          className="main-header__brand"
        >
            Pannellum React Component
        </a>
      </div>
    </header>
  );
};
